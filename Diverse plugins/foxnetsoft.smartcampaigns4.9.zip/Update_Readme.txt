Warning! Before updating plugin we strongly recommend you to go though the following steps!

STEPS:
1. First of all, backup your existing database!
2. Backup your plugin's folder.
3. Copy all files from newly downloaded archive to your plugin folder (all files! It is important!).
4. If you have made any changes then you will need to merge changed files into the new version. Copy your CSS and .CSHTML-files back.
5. Restart your website.
6. Once you have restarted your site, the plugin will execute SQL-update script from Install folder. Plugin upgdates itself.

Note: As you have restarted the site, the plugin checks its version and performs the necessary updates from Install folder.